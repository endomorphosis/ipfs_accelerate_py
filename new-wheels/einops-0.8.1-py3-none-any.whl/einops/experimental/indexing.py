"""
This file contained some thoughts on indexing.

These ideas were developed further in eindex (separate package).
"""
