class test_hardware_backend:
    def __init__(self, resources, metadata):
        self.resources = resources
        self.metadata = metadata
        return None

    def test_webnn(self):
        ## test dependencies
        return None
    
    def test_cuda(self):
        ## test dependencies
        return None

    def test_openvino(self):
        ## test dependencies
        return None
    
    def test_qualcomm(self):
        ## test dependencies
        return None
    
    def test_apple(self):
        ## test dependencies
        return None
    
    def __test__(self):
        self.test_webnn()   
        self.test_cuda()
        self.test_openvino()
        self.test_qualcomm()
        self.test_apple()
        return None