class apple_utils:
    def __init__(self, resources=None, metadata=None):
        return None
    
    def init(self):
        return None