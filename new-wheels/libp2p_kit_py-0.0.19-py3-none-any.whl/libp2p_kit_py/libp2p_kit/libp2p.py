class libp2p_kit:
    def __init__(self, resources, metadata):
        
        return None
    
    def run(self):

        return True